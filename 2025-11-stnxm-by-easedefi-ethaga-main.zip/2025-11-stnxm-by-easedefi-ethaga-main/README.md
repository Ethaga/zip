# stNXM by EaseDeFi contest details

- Join [Sherlock Discord](https://discord.gg/MABEWyASkp)
- Submit findings using the **Issues** page in your private contest repo (label issues as **Medium** or **High**)
- [Read for more details](https://docs.sherlock.xyz/audits/watsons)

# Q&A

### Q: On what chains are the smart contracts going to be deployed?
Ethereum
___

### Q: If you are integrating tokens, are you allowing only whitelisted tokens to work with the codebase or any complying with the standard? Are they assumed to have certain properties, e.g. be non-reentrant? Are there any types of [weird tokens](https://github.com/d-xo/weird-erc20) you want to integrate?
There are no third-party tokens being integrated.
___

### Q: Are there any limitations on values set by admins (or other roles) in the codebase, including restrictions on array lengths?
Owner (NOT proxy owner) should generally not be able to do anything that would allow them to steal from the vault. 

For example, the LP deposit is only allowed on initialization to avoid scenarios where the owner could manipulate LP liquidity (manip price down, supply a large amount of liquidity at a cheap price, buy tokens cheap) to profit.

They can, of course, "DoS" where they supply all withdrawable funds to staking or LP/Morpho or pause the contract, but the proxy owner should be able to stop any malicious activity there. That is not an exploit.

An example of an exploit we would want to know about is if there were a way owner could supply to Morpho, manipulate prices, and somehow end up profiting. If the owner is able to steal the funds that cannot be recovered by the protocol/proxy, then it may be a valid issue (if it leads to Med/High impact).


___

### Q: Are there any limitations on values set by admins (or other roles) in protocols you integrate with, including restrictions on array lengths?
No
___

### Q: Is the codebase expected to comply with any specific EIPs?
No.
___

### Q: Are there any off-chain mechanisms involved in the protocol (e.g., keeper bots, arbitrage bots, etc.)? We assume these mechanisms will not misbehave, delay, or go offline unless otherwise specified.
There will be staking and unstaking that the multisig owner takes care of. You can assume there will never be a tranche where stakes aren't adjusted or updated.

There will also be a mechanism consistently getting rewards (every 1-2 days).
___

### Q: What properties/invariants do you want to hold even if breaking them has a low/unknown impact?
No
___

### Q: Please discuss any design choices you made.
We currently ignore Morpho rewards in total asset calculation for simplicity's sake. If this can be taken advantage of to result in a loss of funds of it may be a valid finding (if leads to standard requirements for Med/High).

We also decided that withdrawals will expire after 1 day of being finalized in order to avoid users maintaining a finalized withdrawal for immediate exit of the vault if a hack occurs.

We do not drip rewards as we have in past versions. A malicious user could withdraw rewards directly to the contract and bypass the dripping so we decided instead to allow small jumps in price but we will call getRewards more often.

Swap exchange rate is hardcoded for now and will be adjusted upon launch.
___

### Q: Please provide links to previous audits (if any) and all the known issues or acceptable risks.
Previous audits were private but:
- Morpho rewards are ignored in total assets.
- Dripping rewards is skipped and instead getRewards will be called fairly often.
- If tranches aren't reset for a long time (6 months+) they will get lost. Keeper will call more often than that.
- There will likely be scenarios where we miss out on some admin fees, such as if fees go uncollected then staked capital is slashed.

We expect all of these to have minor, if any, consequences. If there's a way they can be used to create major consequences that may count as a valid finding. Standard requirements for Medium/High severity apply.
___

### Q: Please list any relevant protocol resources.
- stnxm.com has general info on the product. The app page does not currently have real amount data.
- GitHub README has more detailed technical info.

___

### Q: Additional audit information.
The context of the update is that all the funds and positions will be migrated from the arNXM to the stNXM.sol.

The context of deployment of stNXM.sol:
1. Launch contract and `initialize`
2. Pause contract 
3. Transfer over NFTs, NXM, and ownership from the old arNXM
4. Initialize External
5. Unpause

For the compilation of foundry and hardhat:

`INFURA_API_KEY=OWN_API_KEY
INFURA_API=https://mainnet.infura.io/v3/OWN_API_KEY

MNEMONIC="test test test test test test test test test test test junk"

MAINNET_URL_ALCHEMY=https://eth-mainnet.g.alchemy.com/v2/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
TENDERLY_FORK=https://rpc.tenderly.co/fork/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
MAINNET_INFURA=https://mainnet.infura.io/v3/cccccccccccccccccccccccccccccccc
=cccccccccccccccccccccccccccccccc

BLOCK_NUMBER=16839410
FORKING=true

PRIVATE_KEY1=e916d21c75a564ccb0a51c140c2dec92cb9034202fea65f46ee016828ed0eb63
PRIVATE_KEY2=8b21d3fa24e560354e88e60125b7fe0c2cfb156ed70a092357e361300fc02a56
PRIVATE_KEY3=8b21d3fa24e560354e88e60125b7fe0c2cfb156ed70a092357e361300fc02a56

ETHERSCAN_API_KEY=DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
MAINNET_PRIVATE_KEY=FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
`


# Audit scope

[stNXM-Contracts @ b1431014cfadc4e5b65a9b93dfb52092313fef31](https://github.com/EaseDeFi/stNXM-Contracts/tree/b1431014cfadc4e5b65a9b93dfb52092313fef31)
- [stNXM-Contracts/contracts/core/stNxmOracle.sol](stNXM-Contracts/contracts/core/stNxmOracle.sol)
- [stNXM-Contracts/contracts/core/stNXM.sol](stNXM-Contracts/contracts/core/stNXM.sol)
- [stNXM-Contracts/contracts/core/stNxmSwap.sol](stNXM-Contracts/contracts/core/stNxmSwap.sol)
- [stNXM-Contracts/contracts/general/Ownable.sol](stNXM-Contracts/contracts/general/Ownable.sol)


